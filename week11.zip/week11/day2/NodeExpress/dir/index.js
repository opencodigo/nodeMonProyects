"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
// importando express
var express = require('express');
// creando el servidor web en la cariable app
var app = express();
// donfigurando una ruta y una accion a traves del metodo get (HTTP)
app.get('/', function (req, res) {
    res.send("hola mundo bro xD");
});
// creando una ruta para post
app.post('/miruta', function (req, res) {
    //res.send("hola mundo bro xD");
    res.json({ nombre: 'jorge', apellido: 'Fails' });
});
// iniciando el servidor
app.listen(3000, function () {
    console.log("==> servidor iniciado en el puerto 3000");
});
