import {Request, Response} from 'express'

export let miruta = (req:Request, res:Response) =>{

    res.json({nombre: 'jorge', apellido:'Fails'});
}

export let index =(req:Request, res:Response)=>{
    console.log("Inicio del server");
    res.send('<h1>Hola Peru</h1>');
}