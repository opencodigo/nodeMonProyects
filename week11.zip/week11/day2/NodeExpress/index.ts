import {Request, Response} from 'express';

import { miruta, index} from './api/controllers/home';

// importando express
var express = require('express');

// creando el servidor web en la cariable app
var app = express();
// donfigurando una ruta y una accion a traves del metodo get (HTTP)
app.get('/', index);

// creando una ruta para post
// app.post('/miruta', (req:Request, res:Response)=>{
//     //res.send("hola mundo bro xD");
//     console.log("Alguien solicito mmi ruta");
    
//     res.json({nombre: 'jorge', apellido:'Fails'});
// });

app.post('/miruta', miruta);

// iniciando el servidor
app.listen(3000, ()=> {
    console.log("==> servidor iniciado en el puerto 3000");
    
})



