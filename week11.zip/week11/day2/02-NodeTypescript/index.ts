import {mostrarFecha} from './utils'

console.log("hola mundo");
mostrarFecha();