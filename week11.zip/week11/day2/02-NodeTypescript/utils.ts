export let mostrarFecha = ()=> {

    console.log(new Date());
    
}