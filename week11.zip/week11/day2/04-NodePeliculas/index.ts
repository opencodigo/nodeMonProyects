import {Server} from './api/clases/Server';

let servidor = new Server();

servidor.start();
