import { Request, Response } from 'express';

//creando el objeto de peliculas controller
export let peliculas_controller = {
    getPeliculas: (req: Request, res: Response) => {

        res.json([{
            id: 1,
            nombre: 'harry el Sucio Potter 1'
        }, {
            id: 2,
            nombre: 'harry el Sucio Potter 2'
        }])

    }
}