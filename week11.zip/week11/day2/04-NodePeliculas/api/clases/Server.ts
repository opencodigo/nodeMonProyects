import express from 'express';
// importando desde peliculas router
import {pelicula_router} from './../rutas/Pelicula';
 
export class Server{
    app:express.Application;
    
    constructor(){
        this.app = express();
        this.vincularRutas();
    }

    vincularRutas(){
        this.app.use(pelicula_router);
    }

    start(){
        this.app.listen(3000, ()=>{
            console.log("El servidor se ha iniciado correctamente.");
        });
    }
}