// import { tabla } from "./utils";

// let utils = require ('./utils.js');
// utils.tabla(15);

const {tabla, imprimirTabla} = require('./utils');


// usando require y sus propiedades
// const argv = require('yargs').argv;
const argv = require('yargs')
            .command('crear', ' crea un archivo de la tabla de multiplicar',{
                numero:{
                    demand:true,
                    alias: 'n'
                }
            })
.argv;

//process = variable qgloal que guarda la indormacion de l ejecucion del proyeco
console.log(process.argv[2].split("=")[1]);

// let numero = process.argv[2].split("=")[1];
// tabla(numero);


console.log(argv.numero);
let comando = argv._[0];
switch (comando) {
    case 'crear':
        tabla(argv.numero);
        break;
    case 'mostrar':
        console.log("estamos mostrando");
        break;
    default:
        console.log("Comando Invalido");
}



