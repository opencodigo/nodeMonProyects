const fs = require('fs'); //importando filesystem

var colors = require('colors');

let tabla = (numero)=>{

    //let numero = 8;
    let data ="";  
    
    for (let i = 0; i <=10; i++) {
    data = data + `${numero} * ${i} = ${numero*i}\n `;
    }
    
    fs.writeFile(`./resultados/tabla-del-${numero}`, data, error =>{
        if(error){
            throw error
        }else{
            console.log(`La tabla del ${numero} sido creado con exito`);
            
        }
    })

}



let imprimirTabla = (numero)=>{
    
    for (let i = 0; i <=10; i++) {
    console.log(`${numero} * ${i} = ${numero*i}\n .green` );
     
    }

}

module.exports = {
    // tabla:tabla
    tabla:tabla,
    imprimirTabla:imprimirTabla
}



