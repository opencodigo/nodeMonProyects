//importanto por ES6
import {Router} from 'express';
import { peliculas_controller} from './../controllers/Pelicula';

export var pelicula_router = Router();

pelicula_router.get('/peliculas', peliculas_controller.getPeliculas);